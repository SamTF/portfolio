Hi there :) These maps were made by Sebastião Casaleiro for the 2020/21 Self-Initiated project. You can read up on the all the details about that project on my spaces: https://spaces.colognegamelab.de/improvingleveldesign/

If you just downloaded Quake and aren't sure how to run custom maps such as these, keep reading.

INSTRUCTIONS
------------

1. Place the .bsp map files in your Quake/id1/maps directory
2. Place the .wad texture files in your Quake/id1 folder (or really anywhere inside the Quake directory)
3. Run Quake. Select OPTIONS and then select GO TO CONSOLE
4. Once in the console, type "map m1"
5. Play and have fun :) 