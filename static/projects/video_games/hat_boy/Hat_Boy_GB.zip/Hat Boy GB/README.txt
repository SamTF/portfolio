Strange surroundings.
	Sinister creatures.
		Suspicious skulls.
			And lots o' hats!
			
"Hat Boy" is a narrative puzzle micro-game about exploring a strange underground world with two rival factions with ambiguous motivations that can't seem to see eye to eye... where will you stand? Your actions matter and will lead to one out of seven different endings!

It was created by Sebastião "Sam" Casaleiro
Personal website: https://sam.freelancepolice.org/
Discord: sam.freelancepolice

CONTROLS:
Move - D-Pad
Interact - walk into sprite
Confirm - A
Cancel - B

This file is a Game Boy. This means that to play it, you will need a GameBoy emulator.

For more information visit https://hatboy.freelancepolice.org/